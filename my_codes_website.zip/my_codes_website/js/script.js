// سكريبت الموقع الرئيسي

// تأثير الخلفية المتحركة
document.addEventListener('DOMContentLoaded', function() {
    createBackgroundEffect();
    addHoverEffects();
});

// إنشاء تأثير الخلفية المتحركة
function createBackgroundEffect() {
    const backgroundEffect = document.querySelector('.background-effect');
    
    // إنشاء نقاط متحركة في الخلفية
    for (let i = 0; i < 100; i++) {
        const dot = document.createElement('div');
        dot.classList.add('bg-dot');
        
        // تعيين موقع عشوائي
        const posX = Math.floor(Math.random() * 100);
        const posY = Math.floor(Math.random() * 100);
        
        // تعيين حجم عشوائي
        const size = Math.random() * 3 + 1;
        
        // تعيين خصائص النقطة
        dot.style.right = `${posX}%`;
        dot.style.top = `${posY}%`;
        dot.style.width = `${size}px`;
        dot.style.height = `${size}px`;
        
        // تعيين تأخير عشوائي للحركة
        dot.style.animationDelay = `${Math.random() * 5}s`;
        
        backgroundEffect.appendChild(dot);
    }
}

// إضافة تأثيرات التحويم
function addHoverEffects() {
    // تأثير التحويم على بطاقات الدورات
    const courseCards = document.querySelectorAll('.course-card');
    
    courseCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 10px 20px rgba(0, 255, 0, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 5px 15px rgba(0, 255, 0, 0.1)';
        });
    });
    
    // تأثير التحويم على زر البدء
    const startButton = document.querySelector('.btn-get-started');
    
    if (startButton) {
        startButton.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
        });
        
        startButton.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    }
}

// تأثير كتابة الكود
const codeBlock = document.querySelector('.code-block pre code');
if (codeBlock) {
    const originalText = codeBlock.textContent;
    codeBlock.textContent = '';
    
    let i = 0;
    const typeWriter = setInterval(() => {
        if (i < originalText.length) {
            codeBlock.textContent += originalText.charAt(i);
            i++;
        } else {
            clearInterval(typeWriter);
        }
    }, 50);
}
